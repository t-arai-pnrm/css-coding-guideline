# CSSコーディングガイドライン v0.55.0 のサンプル

原稿の版：0.55.0。ブラウザの対応状況：2026年9月確認のデータ。

## 最小構成

quick-start/index.htmlをブラウザで開きます。淡い灰色のカードに、青い見出し、日付、本文が出れば開始できます。見出しの色はarticleのstyle属性で変えます。

## 実務配信への移行

practical/でnpm install、npm run buildを実行します。Node.js 22.12以降で、Vite 8.3.1がcss/style.cssの@importを展開します。dist/index.htmlとdist/assets/のCSSを配信します。npm run previewでカードの見た目を確認します。インストールにはネットワークが必要です。

## デモと演習

demos/のHTMLには、Web版と同じ共通トークン、リセット、CSS、必要なJavaScriptを含めています。デモ番号とファイルの対応はmanifest.jsonにあります。演習はexercise/の開始版と完成版を使います。ai-coding/は第20章のひな形です。

## 検証と更新

manifest.jsonに、元の依存関係と各ファイルのSHA-256を記録しています。刊行した版を再現するときは、その版のZIPを保存して使います。依存するブラウザの機能には対応状況の差があり、全デモの全状態を検証した記録ではありません。

文章：CC BY 4.0、コード：MIT-0。出典：CSSコーディングガイドライン、TAK、https://t-arai-pnrm.github.io/css-coding-guideline/
